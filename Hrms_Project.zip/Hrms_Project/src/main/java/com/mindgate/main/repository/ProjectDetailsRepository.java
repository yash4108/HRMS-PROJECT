package com.mindgate.main.repository;

public class ProjectDetailsRepository implements ProjectDetailsRepositoryInterface {

}
