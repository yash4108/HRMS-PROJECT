package com.mindgate.main.repository;

public interface ProjectDetailsRepositoryInterface {

}
